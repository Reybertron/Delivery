
import { Marmita, Neighborhood, Customer, Order, AppConfig, OrderStatus } from '../types';

/**
 * LÓGICA SÊNIOR: 
 * Detecta se estamos rodando localmente (localhost).
 * Se sim, conecta direto no backend local (3001) para maior velocidade e estabilidade.
 * Se não, usa o link do ngrok para acesso externo.
 */
const IS_LOCAL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
const API_URL = IS_LOCAL 
  ? 'http://localhost:3001/api' 
  : 'https://eleanora-uncraven-unavowably.ngrok-free.dev/api'; 

const handleResponse = async (res: Response) => {
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.message || `Erro do Servidor: ${res.status}`);
  }
  return res.json();
};

const apiFetch = async (endpoint: string, options?: RequestInit) => {
  const url = `${API_URL}${endpoint}`;
  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'ngrok-skip-browser-warning': 'true', // Necessário para evitar tela de aviso do ngrok
        ...options?.headers,
      },
      mode: 'cors',
    });
    return await handleResponse(response);
  } catch (e: any) {
    console.error(`[CONEXÃO FALHOU] Alvo: ${url}. Verifique se 'node server.js' está rodando.`);
    throw e;
  }
};

export const db = {
  getApiUrl: () => API_URL,

  // CHECKPOINT / BACKUP
  exportBackup: async () => {
    return await apiFetch('/checkpoint/export');
  },
  
  importBackup: async (backupData: any) => {
    return await apiFetch('/checkpoint/import', {
      method: 'POST',
      body: JSON.stringify(backupData)
    });
  },

  getConfig: async (): Promise<AppConfig> => {
    return await apiFetch('/configuracoes');
  },

  saveConfig: async (config: AppConfig) => {
    return await apiFetch('/configuracoes', {
      method: 'POST',
      body: JSON.stringify(config)
    });
  },

  getMenu: async (): Promise<Marmita[]> => {
    return await apiFetch('/marmitas');
  },

  saveMarmita: async (marmita: Omit<Marmita, 'id'>) => {
    return await apiFetch('/marmitas', {
      method: 'POST',
      body: JSON.stringify(marmita)
    });
  },

  updateMarmita: async (id: string, marmita: Omit<Marmita, 'id'>) => {
    return await apiFetch(`/marmitas/${id}`, {
      method: 'PUT',
      body: JSON.stringify(marmita)
    });
  },

  deleteMarmita: async (id: string) => {
    return await apiFetch(`/marmitas/${id}`, { method: 'DELETE' });
  },

  getBairros: async (): Promise<Neighborhood[]> => {
    return await apiFetch('/bairros');
  },

  saveBairro: async (bairro: Neighborhood) => {
    return await apiFetch('/bairros', {
      method: 'POST',
      body: JSON.stringify(bairro)
    });
  },

  deleteBairro: async (name: string) => {
    return await apiFetch(`/bairros/${encodeURIComponent(name)}`, { method: 'DELETE' });
  },

  getCustomer: async (phone: string): Promise<Customer | null> => {
    return await apiFetch(`/clientes/${phone}`);
  },

  saveCustomer: async (customer: Customer) => {
    return await apiFetch('/clientes', {
      method: 'POST',
      body: JSON.stringify(customer)
    });
  },

  getAllCustomers: async (): Promise<Customer[]> => {
    return await apiFetch('/clientes');
  },

  saveOrder: async (order: Order) => {
    return await apiFetch('/pedidos', {
      method: 'POST',
      body: JSON.stringify(order)
    });
  },

  getOrders: async (): Promise<Order[]> => {
    return await apiFetch('/pedidos');
  },

  getLatestOrder: async (phone: string): Promise<Order | null> => {
    return await apiFetch(`/pedidos/ultimo/${phone}`);
  },

  updateOrderStatus: async (id: string, status: OrderStatus) => {
    return await apiFetch(`/pedidos/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    });
  }
};

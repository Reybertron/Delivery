
import express from 'express';
import pkg from 'pg';
import cors from 'cors';
import 'dotenv/config';

const { Pool } = pkg;
const app = express();
const port = 3001;

const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'delivery',
  password: process.env.DB_PASSWORD || 'Sql123!',
  port: parseInt(process.env.DB_PORT || '5432'),
});

app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'ngrok-skip-browser-warning'],
  credentials: true
}));

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

async function bootstrap() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS configuracoes (
        id SERIAL PRIMARY KEY, 
        whatsapp_negocio TEXT, 
        nome_negocio TEXT, 
        salvar_cliente_auto BOOLEAN DEFAULT TRUE, 
        url_logo TEXT, 
        senha_admin TEXT,
        horario_abertura TEXT DEFAULT '08:00',
        horario_fechamento TEXT DEFAULT '14:00'
      );
      CREATE TABLE IF NOT EXISTS marmitas (id SERIAL PRIMARY KEY, nome TEXT NOT NULL, descricao TEXT, preco DECIMAL(10,2) NOT NULL, dia_semana TEXT NOT NULL, categoria TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS bairros (nome TEXT PRIMARY KEY, taxa_entrega DECIMAL(10,2) NOT NULL);
      CREATE TABLE IF NOT EXISTS clientes (telefone TEXT PRIMARY KEY, nome TEXT NOT NULL, cep TEXT, rua TEXT, numero TEXT, complemento TEXT, bairro TEXT);
      CREATE TABLE IF NOT EXISTS pedidos (
        id TEXT PRIMARY KEY, 
        telefone_cliente TEXT, 
        nome_cliente TEXT, 
        endereco_completo TEXT, 
        bairro TEXT, 
        metodo_entrega TEXT, 
        taxa_entrega DECIMAL(10,2), 
        metodo_pagamento TEXT, 
        subtotal DECIMAL(10,2), 
        total DECIMAL(10,2), 
        status TEXT DEFAULT 'Pendente', 
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        itens JSONB
      );
    `);
    
    // Migração: Adiciona colunas se não existirem
    await pool.query(`
      DO $$ 
      BEGIN 
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes' AND column_name='horario_abertura') THEN
          ALTER TABLE configuracoes ADD COLUMN horario_abertura TEXT DEFAULT '08:00';
          ALTER TABLE configuracoes ADD COLUMN horario_fechamento TEXT DEFAULT '14:00';
        END IF;
      END $$;
    `);

    console.log('✅ DBA: Estrutura Postgres Verificada e Otimizada.');
  } catch (err) { console.error('❌ Erro Crítico no Banco:', err.message); }
}
bootstrap();

// --- SISTEMA DE CHECKPOINT (BACKUP) ---
app.get('/api/checkpoint/export', async (req, res) => {
  try {
    const config = await pool.query('SELECT * FROM configuracoes');
    const menu = await pool.query('SELECT * FROM marmitas');
    const bairros = await pool.query('SELECT * FROM bairros');
    const clientes = await pool.query('SELECT * FROM clientes');
    const pedidos = await pool.query('SELECT * FROM pedidos');
    
    res.json({
      timestamp: new Date().toISOString(),
      data: {
        config: config.rows,
        menu: menu.rows,
        bairros: bairros.rows,
        clientes: clientes.rows,
        pedidos: pedidos.rows
      }
    });
  } catch (err) { 
    console.error('Erro ao exportar:', err);
    res.status(500).json({ message: 'Falha ao exportar backup' }); 
  }
});

app.post('/api/checkpoint/import', async (req, res) => {
  const { config, menu, bairros, clientes, pedidos } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM pedidos; DELETE FROM clientes; DELETE FROM bairros; DELETE FROM marmitas; DELETE FROM configuracoes;');
    
    if (config?.length) {
      const c = config[0];
      await client.query('INSERT INTO configuracoes (whatsapp_negocio, nome_negocio, salvar_cliente_auto, url_logo, senha_admin, horario_abertura, horario_fechamento) VALUES ($1, $2, $3, $4, $5, $6, $7)', 
      [c.whatsapp_negocio, c.nome_negocio, c.salvar_cliente_auto, c.url_logo, c.senha_admin, c.horario_abertura || '08:00', c.horario_fechamento || '14:00']);
    }
    for (const m of (menu || [])) await client.query('INSERT INTO marmitas (nome, descricao, preco, dia_semana, categoria) VALUES ($1, $2, $3, $4, $5)', [m.nome, m.descricao, m.preco, m.dia_semana, m.categoria]);
    for (const b of (bairros || [])) await client.query('INSERT INTO bairros (nome, taxa_entrega) VALUES ($1, $2)', [b.nome, b.taxa_entrega]);
    for (const cl of (clientes || [])) await client.query('INSERT INTO clientes (telefone, nome, cep, rua, numero, complemento, bairro) VALUES ($1, $2, $3, $4, $5, $6, $7)', [cl.telefone, cl.nome, cl.cep, cl.rua, cl.numero, cl.complemento, cl.bairro]);
    for (const p of (pedidos || [])) await client.query('INSERT INTO pedidos (id, telefone_cliente, nome_cliente, endereco_completo, bairro, metodo_entrega, taxa_entrega, metodo_pagamento, subtotal, total, status, criado_em, itens) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)', [p.id, p.telefone_cliente, p.nome_cliente, p.endereco_completo, p.bairro, p.metodo_entrega, p.taxa_entrega, p.metodo_pagamento, p.subtotal, p.total, p.status, p.criado_em, JSON.stringify(p.itens || [])]);
    
    await client.query('COMMIT');
    res.json({ success: true });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Erro ao importar:', err);
    res.status(500).json({ message: 'Falha ao importar backup: ' + err.message });
  } finally { client.release(); }
});

// --- ENDPOINTS PADRÃO ---
app.get('/api/configuracoes', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM configuracoes LIMIT 1');
    if (result.rows.length === 0) return res.json({ businessName: 'Panelas da Vanda', businessWhatsApp: '5511999999999', autoSaveCustomer: true, openingTime: '08:00', closingTime: '14:00' });
    const row = result.rows[0];
    res.json({ 
      businessWhatsApp: row.whatsapp_negocio, 
      businessName: row.nome_negocio, 
      autoSaveCustomer: row.salvar_cliente_auto, 
      logoUrl: row.url_logo, 
      adminPassword: row.senha_admin,
      openingTime: row.horario_abertura,
      closingTime: row.horario_fechamento
    });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/configuracoes', async (req, res) => {
  const { businessWhatsApp, businessName, autoSaveCustomer, logoUrl, adminPassword, openingTime, closingTime } = req.body;
  try {
    await pool.query('DELETE FROM configuracoes');
    await pool.query('INSERT INTO configuracoes (whatsapp_negocio, nome_negocio, salvar_cliente_auto, url_logo, senha_admin, horario_abertura, horario_fechamento) VALUES ($1, $2, $3, $4, $5, $6, $7)', 
    [businessWhatsApp, businessName, autoSaveCustomer, logoUrl, adminPassword, openingTime || '08:00', closingTime || '14:00']);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/marmitas', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM marmitas ORDER BY id DESC');
    res.json(result.rows.map(r => ({ id: r.id.toString(), name: r.nome, description: r.descricao, price: parseFloat(r.preco), day: r.dia_semana, category: r.categoria })));
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/marmitas', async (req, res) => {
  const { name, description, price, day, category } = req.body;
  try {
    const result = await pool.query('INSERT INTO marmitas (nome, descricao, preco, dia_semana, categoria) VALUES ($1, $2, $3, $4, $5) RETURNING id', [name, description, price, day, category]);
    res.json({ id: result.rows[0].id });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.put('/api/marmitas/:id', async (req, res) => {
  const { id } = req.params;
  const { name, description, price, day, category } = req.body;
  try {
    await pool.query('UPDATE marmitas SET nome=$1, descricao=$2, preco=$3, dia_semana=$4, categoria=$5 WHERE id=$6', [name, description, price, day, category, id]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.delete('/api/marmitas/:id', async (req, res) => {
  try { await pool.query('DELETE FROM marmitas WHERE id=$1', [req.params.id]); res.json({ success: true }); }
  catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/bairros', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM bairros ORDER BY nome');
    res.json(result.rows.map(r => ({ name: r.nome, deliveryFee: parseFloat(r.taxa_entrega) })));
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/bairros', async (req, res) => {
  const { name, deliveryFee } = req.body;
  try {
    await pool.query('INSERT INTO bairros (nome, taxa_entrega) VALUES ($1, $2) ON CONFLICT (nome) DO UPDATE SET taxa_entrega = EXCLUDED.taxa_entrega', [name, deliveryFee]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.delete('/api/bairros/:name', async (req, res) => {
  try { await pool.query('DELETE FROM bairros WHERE nome=$1', [req.params.name]); res.json({ success: true }); }
  catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/clientes', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM clientes ORDER BY nome');
    res.json(result.rows.map(r => ({ phone: r.telefone, name: r.nome, cep: r.cep, street: r.rua, number: r.numero, complement: r.complemento, neighborhood: r.bairro })));
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/clientes/:phone', async (req, res) => {
  try {
    const { phone } = req.params;
    const result = await pool.query('SELECT * FROM clientes WHERE telefone = $1', [phone]);
    if (result.rows.length === 0) return res.json(null);
    const r = result.rows[0];
    res.json({ phone: r.telefone, name: r.nome, cep: r.cep, street: r.rua, number: r.numero, complement: r.complemento, neighborhood: r.bairro });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/clientes', async (req, res) => {
  const { phone, name, cep, street, number, complement, neighborhood } = req.body;
  try {
    await pool.query(`INSERT INTO clientes (telefone, nome, cep, rua, numero, complemento, bairro) VALUES ($1, $2, $3, $4, $5, $6, $7) ON CONFLICT (telefone) DO UPDATE SET nome=$2, cep=$3, rua=$4, numero=$5, complemento=$6, bairro=$7`, [phone, name, cep, street, number, complement, neighborhood]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/pedidos', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM pedidos ORDER BY criado_em DESC');
    res.json(result.rows.map(r => ({ 
      id: r.id, 
      customerPhone: r.telefone_cliente, 
      customerName: r.nome_cliente, 
      customerAddress: r.endereco_completo, 
      neighborhood: r.bairro, 
      deliveryMethod: r.metodo_entrega, 
      deliveryFee: parseFloat(r.taxa_entrega), 
      paymentMethod: r.metodo_pagamento, 
      subtotal: parseFloat(r.subtotal), 
      total: parseFloat(r.total), 
      status: r.status, 
      createdAt: r.criado_em,
      items: Array.isArray(r.itens) ? r.itens : []
    })));
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.get('/api/pedidos/ultimo/:phone', async (req, res) => {
  try {
    const { phone } = req.params;
    const result = await pool.query('SELECT * FROM pedidos WHERE telefone_cliente = $1 ORDER BY criado_em DESC LIMIT 1', [phone]);
    if (result.rows.length === 0) return res.json(null);
    const r = result.rows[0];
    res.json({ 
      id: r.id, 
      customerPhone: r.telefone_cliente, 
      customerName: r.nome_cliente, 
      customerAddress: r.endereco_completo, 
      neighborhood: r.bairro, 
      deliveryMethod: r.metodo_entrega, 
      deliveryFee: parseFloat(r.taxa_entrega), 
      paymentMethod: r.metodo_pagamento, 
      subtotal: parseFloat(r.subtotal), 
      total: parseFloat(r.total), 
      status: r.status, 
      createdAt: r.criado_em,
      items: Array.isArray(r.itens) ? r.itens : []
    });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/pedidos', async (req, res) => {
  const { id, customerPhone, customerName, customerAddress, neighborhood, deliveryMethod, deliveryFee, paymentMethod, subtotal, total, items } = req.body;
  try {
    await pool.query(`INSERT INTO pedidos (id, telefone_cliente, nome_cliente, endereco_completo, bairro, metodo_entrega, taxa_entrega, metodo_pagamento, subtotal, total, itens) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`, [id, customerPhone, customerName, customerAddress, neighborhood, deliveryMethod, deliveryFee, paymentMethod, subtotal, total, JSON.stringify(items || [])]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.patch('/api/pedidos/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  try {
    await pool.query('UPDATE pedidos SET status = $1 WHERE id = $2', [status, id]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.listen(port, '0.0.0.0', () => {
  console.log(`\n🚀 SERVIDOR BACKEND RODANDO NA PORTA ${port}`);
});
